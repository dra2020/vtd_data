This download contains demographic and/or election data as used in Dave's Redistricting App. You are responsible for reading and understanding the associated licenses for this data.

The shapefile matching this data can be found here: https://www2.census.gov/geo/tiger/TIGER2020PL/STATE/72_Puerto_Rico/72/tl_2020_72_vtd20.zip .

The first two CSV Columns are GEOID20 and Name (name of the VTD).
Subsequent CSV Column Headings are in the form <category>_<year>_<dataset>[_<optional modifier>]_<field>.

Categories
	-- T = Total Population
	-- V = Voting Age Population
	-- E = Elections

Demographic Datasets (Persons)
	-- CENS = Total Population from the decennial census
	-- CENS_ADJ = Total Population from the decennial census, Adjusted for incarcerated persons
	-- ACS = Total Population from the 5-year American Community Survey estimate
	-- VAP = Voting Age Population with Race Combination categories from the decennial census
	-- VAP_NH = Voting Age Population with Non-Hispanic Race Alone categories from the decennial census
	-- CVAP = Citizen Voting Age Population based on the 5-year American Community Survey estimate

Demographic Field Names
	-- Total = Total persons
	-- White = White alone, not Hispanic
	-- Hispanic = All Hispanics regardless of race
	-- Black = Black alone or in combination with other races, including Hispanic
	-- Asian = Asian alone or in combination with other races, including Hispanic
	-- Native = American Indian and Alaska Native alone or in combination with other races, including Hispanic
	-- Pacific = Native Hawaiian and Pacific Islander alone or in combination with other races, including Hispanic
	-- BlackAlone = Black alone, not Hispanic
	-- AsianAlone = Asian alone, not Hispanic
	-- NativeAlone = American Indian and Alaska Native alone, not Hispanic
	-- PacificAlone = Native Hawaiian and Pacific Islander alone, not Hispanic
	-- OtherAlone = Other race alone, not Hispanic
	-- TwoOrMore = Two or more races, not Hispanic
	-- RemTwoOrMore = Remainder of two or more races, not Hispanic (for CVAP only because it does not include some race combinations already included other fields)


Datasets included in this package:
	-- T_20_CENS
	-- T_20_ACS
	-- V_20_VAP
	-- V_20_VAP_NH
	-- V_20_CVAP
