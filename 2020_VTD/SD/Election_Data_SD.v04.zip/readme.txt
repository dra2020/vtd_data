This download contains demographic and/or election data as used in Dave's Redistricting App. You are responsible for reading and understanding the associated licenses for this data.

The shapefile matching this data can be found here: https://www2.census.gov/geo/tiger/TIGER2020PL/STATE/46_South_Dakota/46/tl_2020_46_vtd20.zip .

The first two CSV Columns are GEOID20 and Name (name of the VTD).
Subsequent CSV Column Headings are in the form <category>_<year>_<dataset>[_<optional modifier>]_<field>.

Categories
	-- T = Total Population
	-- V = Voting Age Population
	-- E = Elections

Election Datasets (Votes)
	-- COMP = DRA's Composite
	-- PRES = President
	-- SEN = U.S. Senator
	-- GOV = Governor
	-- AG = Attorney General
	-- AUD = Auditor
	-- LTG = Lieutenant Governor
	-- SOS = Secretary of State
	-- TREAS = Treasurer
	-- SC* = State Supreme Court (with seat designation)
	-- CONG = U.S. Congress

Modifiers
	-- ROFF = Runoff election
	-- SPEC = Special election
	-- SPECROFF = Special Runoff election

Election Field Names
	-- Tot = Total votes
	-- Dem = Democratic votes
	-- Rep = Republican votes


Datasets included in this package:
	-- E_16_PRES
	-- E_16_SEN
	-- E_18_GOV
	-- E_18_AG
	-- E_16-20_COMP
	-- E_20_PRES
	-- E_20_SEN
